const { test, expect } = require('@playwright/test');

// 1  Prueba de Login correcto y cambio de pagina
test('login correcto', async ({ page }) => {
  await page.goto('https://www.saucedemo.com/'); // 1  Pagina famosa para pruebas de login
  await page.fill('#user-name', 'standard_user');
  await page.fill('#password', 'secret_sauce');
  await page.click('#login-button');

  await expect(page).toHaveURL('https://www.saucedemo.com/inventory.html');
});




// 2 Prueba de Login con clave mala para el error
test('login con error', async ({ page }) => {
  await page.goto('https://www.saucedemo.com/');
  await page.fill('#user-name', 'standard_user');
  await page.fill('#password', '1234');
  await page.click('#login-button');

  await expect(page.locator('.error-message-container')).toBeVisible();
});




// 3 Prueba der Boton agregar al carrito y abrir carrito
test('agregar al carrito', async ({ page }) => {
  await page.goto('https://www.saucedemo.com/');
  await page.fill('#user-name', 'standard_user');
  await page.fill('#password', 'secret_sauce');
  await page.click('#login-button');

  await page.click('#add-to-cart-sauce-labs-backpack');
  await page.click('.shopping_cart_link');

  await expect(page).toHaveURL('https://www.saucedemo.com/cart.html');
});




// 4 Prueba de api que da como respuesta 200 
test('api responde 200', async ({ request }) => {
  const respuesta = await request.get('https://jsonplaceholder.typicode.com/posts/1');
  expect(respuesta.status()).toBe(200);

  const json = await respuesta.json();
  expect(json.id).toBe(1);
});



// 5 Prueba de la api da 404 cuando no existe
test('api responde 404', async ({ request }) => {
  const respuesta = await request.get('https://jsonplaceholder.typicode.com/posts/99999');
  expect(respuesta.status()).toBe(404);
});